# Current Version of the Text Parser is v6.
# Use the files in the repository (HansaMarketFullFiles.zip) to test the program.
